const fs = require('fs')
global.tokens = ["07a28470b3126b0aaf8581bc9d463fb2c412a0257f760302c96ce4d2a8908c8c"]
global.connect = true
global.publicX = true 
global.owner = ['6285924514965'] 
global.prefa = ['','!','.',',','🐤','🗿']

let file = require.resolve(__filename)
require('fs').watchFile(file, () => { 
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
}