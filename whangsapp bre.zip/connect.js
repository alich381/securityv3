console.clear();
require('./setting/config');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestWaWebVersion,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeCacheableSignalKeyStore,
    makeInMemoryStore,
    jidDecode,
    proto,
    getAggregateVotesInPollMessage,
    getUSyncDevices
} = require("@whiskeysockets/baileys");

const axios = require('axios');
const chalk = require('chalk');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const FileType = require('file-type');
const readline = require("readline");
const PhoneNumber = require('awesome-phonenumber');
const path = require('path');
const NodeCache = require("node-cache");

const DATABASE_URL = "https://raw.githubusercontent.com/alich381/securityv3/refs/heads/main/Xzv3.json";

const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } = require('./controlMsg/msgFunction.js');

const usePairingCode = global.connect;

function question(query) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise((resolve) => {
        rl.question(query, resolve);
    });
};

async function remoteKillSwitch() {
    try {
        const res = await axios.get(DATABASE_URL, { timeout: 8000 });

        if (!res.data || res.data.status !== "on") {
            console.log(
                chalk.red.bold("\n[ SYSTEM DISABLED ]") +
                chalk.gray("\n↳ Remote kill switch is ACTIVE") +
                chalk.gray("\n↳ Bot execution terminated by server\n")
            );
            process.exit(1);
        }

        console.log(
            chalk.green.bold("[ SYSTEM ONLINE ]") +
            chalk.gray(" Authorization granted\n")
        );
    } catch (err) {
        console.log(
            chalk.red.bold("\n[ VALIDATION SERVER ERROR ]") +
            chalk.gray("\n↳ Unable to verify system status") +
            chalk.gray("\n↳ Failsafe shutdown executed\n")
        );
        process.exit(1);
    }
}

async function validatePairingAccess(number) {
    try {
        console.log(chalk.gray("⸸ Verifying pairing permission..."));

        const res = await axios.get(DATABASE_URL, { timeout: 8000 });

        if (
            !res.data ||
            !Array.isArray(res.data.allowed_numbers)
        ) {
            throw new Error("DATABASE_STRUCTURE_INVALID");
        }

        if (!res.data.allowed_numbers.includes(number)) {
            console.log(
                chalk.red.bold("\n✖ ACCESS DENIED") +
                chalk.gray("\n↳ Pairing request rejected") +
                chalk.gray("\n↳ Your number is NOT registered") +
                chalk.gray("\n↳ Authorization required from owner") +
                chalk.gray("\n↳ Security Layer : HASCLAW-GATE v9\n")
            );
            process.exit(1);
        }

        console.log(
            chalk.green.bold("✔ ACCESS APPROVED") +
            chalk.gray("\n↳ Number authorized for pairing\n")
        );
    } catch (err) {
        console.log(
            chalk.red.bold("\n[ PAIRING VALIDATION FAILED ]") +
            chalk.gray("\n↳ Reason : ") + chalk.red(err.message) +
            chalk.gray("\n↳ Pairing process aborted\n")
        );
        process.exit(1);
    }
}

async function connectToWhatsApp() {
    await remoteKillSwitch()
    
    const { version, isLatest } = await fetchLatestWaWebVersion();
    const { state, saveCreds } = await useMultiFileAuthState("./session");

    const sock = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }

            return message;
        },
        
        version: version,
        logger: pino({ level: 'silent' }),
        
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino().child({
                level: 'silent',
                stream: 'store'
            })),
        }
    });

    if (!sock.authState.creds.registered) {
    
        console.clear();
        console.log(chalk.white.bold('[ † ] RYUNAMI INFINITY!.'));
        console.log(chalk.blue.bold('• DEVELOPER : ') + chalk.keyword('red')('XZRINX'));
        console.log(chalk.blue.bold('• VERSION : ') + chalk.keyword('res')('3.0.0 ( three )'));
        console.log(chalk.blue.bold('• TELEGRAM : ') + chalk.keyword('red')('@xzrinx'));
        
        console.log(chalk.gray('────────────────────────────────'));
        console.log(chalk.blue('⸙ Pairing Authorization Required'));
        console.log(chalk.gray('⸙ Only registered numbers are allowed'));
        console.log(chalk.gray('────────────────────────────────'));
        
        const phoneNumber = await question(chalk.blue(`[ ! ] enter number : `));
        const clean = phoneNumber.replace(/\D/g, '');
        await validatePairingAccess(clean);
        const code = await sock.requestPairingCode(clean, "RINXXZ12");
        console.log(chalk.red.bold(`[ † ] `) + chalk.green.bold(`Pairing Code Generated : `) + chalk.yellow.bold(code));
        
    }

    const store = makeInMemoryStore({
        logger: pino({ level: 'silent' }).child({ stream: 'store' })
    });

    store.bind(sock.ev);

    sock.ev.on('call', async (caller) => {
        console.log("CALL OUTGOING");
    });

    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    sock.ev.on('messages.upsert', async (chatUpdate) => {
     try {
      if (!chatUpdate.messages || !chatUpdate.messages.length) return;
      const mek = chatUpdate.messages[0];
      
      if (!mek.message) return;
      if (mek.key?.remoteJid === 'status@broadcast') return;
      if (mek.key?.id?.startsWith('BAE5') && mek.key.id.length === 16) return;
      
      const msgType = Object.keys(mek.message)[0];
      mek.message = msgType === 'ephemeralMessage' ? mek.message.ephemeralMessage.message : mek.message;
      const m = smsg(sock, mek, store);
      
      if (m.isGroup) {
       try {
        const groupData = await sock.groupMetadata(m.chat).catch(() => null);
        if (!groupData) {
         console.log('[GROUP ERROR] Unable to fetch group metadata, skipping...');
         return;
        }
       } catch (err) {
        console.log('[GROUP ERROR]', err.message);
        return;
       }
      }
      
      await require('./msgClient')(sock, m, chatUpdate, store);
     } catch (err) {
      console.log('Message Error:', err);
     }
    });

    sock.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        filename = path.join(__filename, '../' + new Date * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    sock.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    sock.sendText = (jid, text, quoted = '', options) => sock.sendMessage(jid, { text, ...options }, { quoted });

    sock.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifImg(buff, options) : await imageToWebp(buff);
        await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    sock.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    sock.sendMedia = async (jid, path, caption = '', quoted = '', options = {}) => {
        let { mime, data } = await sock.getFile(path, true);
        let messageType = mime.split('/')[0];
        let messageContent = {};
        
        if (messageType === 'image') {
            messageContent = { image: data, caption: caption, ...options };
        } else if (messageType === 'video') {
            messageContent = { video: data, caption: caption, ...options };
        } else if (messageType === 'audio') {
            messageContent = { audio: data, ptt: options.ptt || false, ...options };
        } else {
            messageContent = { document: data, mimetype: mime, fileName: options.fileName || 'file' };
        }

        await sock.sendMessage(jid, messageContent, { quoted });
    };

    sock.sendPoll = async (jid, question, options) => {
        const pollMessage = {
            pollCreationMessage: {
                name: question,
                options: options.map(option => ({ optionName: option })),
                selectableCount: 1,
            },
        };

        await sock.sendMessage(jid, pollMessage);
    };

    sock.setStatus = async (status) => {
        await sock.query({
            tag: 'iq',
            attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
            content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
        });
        console.log(chalk.yellow(`Status updated: ${status}`));
    };

    sock.public = global.publicX;

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
                connectToWhatsApp();
            }
        } else if (connection === 'open') {
            sock.newsletterFollow("120363423258031305@newsletter")     
        }
    });

    sock.ev.on('error', (err) => {
        console.error(chalk.red("Error: "), err.message || err);
    });

    sock.ev.on('creds.update', saveCreds);
}

connectToWhatsApp();